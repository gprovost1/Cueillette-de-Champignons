package com.example.guillaume.essai;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    ArrayAdapter<String> adapter2;
    String[] liste_recettes = {"velouté de champignons", "blanquette de veau", "omelette au champignon"};
    //ArrayList<RecetteChampignons> liste_recettes = new ArrayList<RecetteChampignons>();
    ListView listView;
    ListView list_recette;
    public ArrayList<Recette> recettes;



    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ListeNomRecette liste = new ListeNomRecette(recettes);


        spinner = (Spinner) findViewById(R.id.spinner);
        adapter = ArrayAdapter.createFromResource(this,R.array.recettes_titre, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), parent.getItemIdAtPosition(position)+"selected", Toast.LENGTH_LONG).show();
                //list_recette.setSelection(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        listView = (ListView)findViewById(R.id.listView);
        //list_recette=(ListView)findViewById(R.id.list_recette);
        adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, liste_recettes);
        listView.setAdapter(adapter2);


        ListView listView = (ListView) findViewById(R.id.listView);

        /*listView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainRecette.class);
                startActivity(intent);
            }
        });*/

        listView.setOnItemClickListener(new OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getBaseContext(), parent.getItemIdAtPosition(position)+" is selected", Toast.LENGTH_LONG).show();
                //Toast.makeText(MainActivity.this, recettes.size() + position, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, MainRecette.class);
                startActivity(intent);
            }
         });

        /*final ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, liste.hashCode());
        listView.setAdapter(adapter3);*/
        //appelXML();

       // setImageRecette();

    }

    /*private void setImageRecette() {
    }*/

   /* private void appelXML (){
        XmlPullParserFactory ParserFactory;
        try {
            ParserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = ParserFactory.newPullParser();
            InputStream inputStream =getApplicationContext().getAssets().open("data.xml");
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(inputStream, null);
            parseXML(parser);
        }
        catch (XmlPullParserException e) {
        }
        catch (IOException e) {
        }
    }

    private void parseXML(XmlPullParser parser) throws XmlPullParserException, IOException {
        ArrayList<Recette>recettes = new ArrayList<>();
        int eventType = parser.getEventType();
        Recette currentRecette = null;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String name = null;
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    name = parser.getName();
                    if ("recette".equals(name)) {
                        currentRecette = new Recette();
                    }
                    else if (currentRecette != null) {
                        if ("nomRecette".equals(name)) {
                            currentRecette.titre = parser.nextText();
                        }
                    }
                    break;
            }
            recettes.add(currentRecette);
            eventType = parser.next();
        }
        printRecettes(recettes);
    }

    private void printRecettes(ArrayList<Recette> recettes){
        StringBuilder builder = new StringBuilder();

        for(Recette recette : recettes) {
            builder.append(recette.titre).append("\n");
        }
    }*/
}
