package com.example.guillaume.essai;

import android.media.Image;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by Guillaume on 22/03/2018.
 */

public class MainRecette extends AppCompatActivity {

    TextView titreRecette;
    TextView ListeIngredient;
    TextView ListeInstruction;
    ImageView imageRecette;

    public ArrayList<Recette> recettes;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recette_main);
        titreRecette = (TextView)findViewById(R.id.titreRecette);
        ListeIngredient = (TextView) findViewById(R.id.ListeIngredient);
        ListeInstruction = (TextView) findViewById(R.id.ListeInstruction);
        //imageReccette = (ImageView)findViewById(R.id.ImagePlat);

        //appelXML();
    }
    private void appelXML (){
        XmlPullParserFactory pullParserFactory;
        try {
            pullParserFactory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = pullParserFactory.newPullParser();
            InputStream inputStream =getApplicationContext().getAssets().open("data.xml");
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            parser.setInput(inputStream, null);
            parseXML(parser);
        }
        catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private void parseXML(XmlPullParser parser) throws XmlPullParserException, IOException {
        ArrayList<Recette>recettes = new ArrayList<>();
        int eventType = parser.getEventType();
        Recette currentRecette = null;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String name = null;
            switch (eventType) {
                case XmlPullParser.START_TAG:
                    name = parser.getName();
                    if ("recette".equals(name)) {
                        currentRecette = new Recette();
                    }
                    else if (currentRecette != null) {
                        if ("nomRecette".equals(name)) {
                            currentRecette.titre = parser.nextText();
                        }
                        else if ("ingredient".equals(name)) {
                            currentRecette.ingredient = parser.nextText();
                        }
                        else if ("etape".equals(name)) {
                            currentRecette.instructions = parser.nextText();
                        }
                    }
                    break;
            }
            //recettes.add(currentRecette);
            eventType = parser.next();
        }
        printRecettes(recettes);
    }


    private void printRecettes(ArrayList<Recette> recettes){
        StringBuilder builder1 = new StringBuilder();
        StringBuilder builder2 = new StringBuilder();
        StringBuilder builder3 = new StringBuilder();

        for(Recette recette : recettes) {
            builder1.append(recette.titre).append("\n");
            builder2.append(recette.ingredient).append("\n");
            builder3.append(recette.instructions).append("\n");
        }
        titreRecette.setText(builder1.toString());
        ListeIngredient.setText(builder2.toString());
        ListeInstruction.setText(builder3.toString());
    }

}
