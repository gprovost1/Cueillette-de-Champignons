package com.example.guillaume.essai;

import android.media.Image;

/**
 * Created by Guillaume on 22/03/2018.
 */

public class RecetteChampignons {

    Image image;
    String titre;

    public RecetteChampignons(Image image, String titre) {
        this.image = image;
        this.titre = titre;
    }


}
