package com.example.guillaume.recettesavecdeschampignons;

import android.widget.ArrayAdapter;

import java.util.ArrayList;

/**
 * Created by Guillaume on 29/03/2018.
 */

class ListeNomRecette {

    ArrayList<Recette> listeNomRecette;


    public ListeNomRecette(ArrayList<Recette> listeNomRecette) {
        this.listeNomRecette=listeNomRecette;
    }

    public Recette get() {
        Recette recette = null;
        for (int i = 0; i < listeNomRecette.size(); i++){
            recette=listeNomRecette.get(i);
        }
        return recette;
    }


    /*public ArrayList<String> get() {
        ArrayList<String> nomRecette = new ArrayList();
        for (int i=0; i<listeNomRecette.size(); i++){
            nomRecette.add(listeNomRecette.get(i).getTitre());
        }
        return nomRecette;
    }*/
}
