package com.example.guillaume.recettesavecdeschampignons;

import android.media.Image;

import java.util.ArrayList;

/**
 * Created by Guillaume on 20/03/2018.
 */

public class Recette {
    protected String titre;
    protected Image image;
    protected String duree;
    protected String nombrePers;
    protected String ingredient;
    protected String instructions;
    protected int id;

   public Recette(String titre, Image image, String duree, String nombrePers, String ingredient, String instructions, int id) {
        this.titre = titre;
        this.image = image;
        this.duree = duree;
        this.id = id;
        this.nombrePers = nombrePers;
        this.ingredient = ingredient;
        this.instructions = instructions;
    }

    public Recette() {
    }

    public String getTitre() {

        return titre;
    }

    public Image getImage() {

        return image;
    }

    public String getDuree() {

       return duree;
    }

    public String getNombrePers() {

       return nombrePers;
    }

    public String getIngredient() {

       return ingredient;
    }

    public String getInstructions() {

       return instructions;
    }

    public int getId() {
        return id;
    }
}
