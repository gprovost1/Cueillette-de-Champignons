package com.example.guillaume.recettesavecdeschampignons;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Guillaume on 29/03/2018.
 */

class CustomAdapter extends BaseAdapter{

    private Context Context;
    private List<Recette> RecetteList;

    public CustomAdapter(Context context, List<Recette> recetteList) {
        this.Context = context;
        this.RecetteList = recetteList;
    }

    @Override
    public int getCount() {
        return RecetteList.size();
    }

    @Override
    public Object getItem(int position) {
        return RecetteList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate(Context, R.layout.item_recette_list, null);
        TextView nomRecette = (TextView)v.findViewById(R.id.titreRecette);
        ImageView imageRecettte = (ImageView)v.findViewById(R.id.ImagePlat);
        nomRecette.setText(RecetteList.get(position).getTitre());

        v.setTag(RecetteList.get(position).getId());
        return v;
    }
}
