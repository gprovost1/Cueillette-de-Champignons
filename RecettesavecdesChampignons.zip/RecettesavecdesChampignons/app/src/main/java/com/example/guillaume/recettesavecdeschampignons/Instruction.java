package com.example.guillaume.recettesavecdeschampignons;

/**
 * Created by Guillaume on 20/03/2018.
 */

public class Instruction {
    private String contenu;

    public Instruction(String contenu) {

        this.contenu = contenu;
    }

    public String getContenu() {

        return contenu;
    }
}
