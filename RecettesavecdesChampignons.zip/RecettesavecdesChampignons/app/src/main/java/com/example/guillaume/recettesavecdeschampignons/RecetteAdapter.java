package com.example.guillaume.recettesavecdeschampignons;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by Guillaume on 20/03/2018.
 */

public class RecetteAdapter extends ArrayAdapter<Recette>{

    public RecetteAdapter (Context context, int resource) {
        super(context, resource);
    }

    public View getView (int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View v;

        LayoutInflater layoutInflater= (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        v = layoutInflater.inflate(R.layout.recette_main, null);

        Recette currentRecette = getItem(position);

        TextView titreRecette = (TextView)v.findViewById(R.id.titreRecette);
        ImageView imagePlat = (ImageView)v.findViewById(R.id.ImagePlat);

        titreRecette.setText(currentRecette.getTitre());

        return v;

    }
}
